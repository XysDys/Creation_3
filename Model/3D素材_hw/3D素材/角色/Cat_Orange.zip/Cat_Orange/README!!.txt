Hey!! thanks for downloading this!!

-- Please ask me if something is wrong i'll try my best to fix it

!!rules!! :

-do not get this model involved in ANY suggestive content ty

-please credit me and PLEASEE credit the person who uploaded the model too!!

-do not use this model for hateful content

!!u can!! :

-edit the model

-and anything else that isn't weird

------------------------------------------

ty for reading!!<333







