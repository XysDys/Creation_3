規約は特にありません。頑張ってください。

カメラの位置は"0"フレームから普通に入れれば問題ないです。

ただキャラクターモーションの位置も添付画像のように"6F"までずらすのをお奨めします。

これはYoutube音源に合わせてカメラを作る際に、モーションのズレを感じたためです。

実際に"モーションキャプチャーされている動画"に合わせた結果です。


No copyright.You can use anything.

I recommend shifting the character's motion up to 6F.

And I also recommend using Youtube sound sources.GoodLuck!

かめりあ - ヒアソビ (feat. 初音ミク) 
https://www.youtube.com/watch?v=od4QcDPpNVk