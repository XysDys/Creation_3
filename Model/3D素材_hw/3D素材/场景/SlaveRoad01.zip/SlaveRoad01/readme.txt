規約は特にありません。頑張ってください。

Raymmd前提で作ったので、ToonShader系だとさっぱりだと思います。

This stage is Only for Ray-mmd.

No copyright.You can use for anything.Goodluck.